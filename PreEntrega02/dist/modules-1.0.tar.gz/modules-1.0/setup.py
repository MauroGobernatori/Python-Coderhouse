from setuptools import setup

setup(
    name="modules",
    version="1.0",
    description="Paquete redistribuido de la Pre-entrega número 2",
    author="Mauro Gobernatori",
    author_email="mauro.gobernatori@gmail.com",
    packages=["modules"]
)